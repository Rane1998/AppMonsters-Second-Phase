package com.example.appmonsters;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class CurrencyConverter extends AppCompatActivity {
    EditText Value;
    Spinner currency_array2 , currency_array;
    Button convert;
    EditText OutputValue;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter_dashboard);

        Value = findViewById(R.id.Value);
        currency_array2 = findViewById(R.id.currency_array2);
        currency_array = findViewById(R.id.currency_array);
        convert = findViewById(R.id.convert);
        OutputValue = findViewById(R.id.OutputValue);

        convert.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (Value.getText().length() == 0){
                    Toast.makeText(CurrencyConverter.this, "Please Enter a Currency Value..!", Toast.LENGTH_SHORT).show();
                    return;
                }

                float inputValue = Float.parseFloat(Value.getText().toString());
            }
        });
    }
}